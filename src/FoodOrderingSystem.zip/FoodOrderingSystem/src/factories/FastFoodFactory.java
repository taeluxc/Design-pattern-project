package factories;

import products.*;

public class FastFoodFactory implements RestaurantFactory {

    public Meal createMeal() {
        return new FastFoodMeal();
    }

    public Drink createDrink() {
        return new FastFoodDrink();
    }

    public Dessert createDessert() {
        return new FastFoodDessert();
    }
}