
package factories;
import products.*; 

public class ItalianFactory implements RestaurantFactory {
    
    public Meal createMeal() {
        return new ItalianMeal();
    }

    public Drink createDrink() {
        return new ItalianDrink();
    }

    public Dessert createDessert() {
        return new ItalianDessert();
    }
    
}
