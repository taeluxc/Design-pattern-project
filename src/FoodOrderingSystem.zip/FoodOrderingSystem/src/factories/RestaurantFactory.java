
package factories;
import products.*;


public interface RestaurantFactory {
      Meal createMeal();
    Drink createDrink();
    Dessert createDessert();
    
}
