
package foodorderingsystem;


import factories.*;
import products.*;
public class FoodOrderingSystem {

   
    public static void main(String[] args) {
     // RestaurantFactory factory = new FastFoodFactory();
       RestaurantFactory factory = new ItalianFactory(); 
       
        Meal meal = factory.createMeal();
        Drink drink = factory.createDrink();
        Dessert dessert = factory.createDessert();

        meal.prepare();
        drink.serve();
        dessert.make();
        
        
        
        
        
        
    }
    
}
