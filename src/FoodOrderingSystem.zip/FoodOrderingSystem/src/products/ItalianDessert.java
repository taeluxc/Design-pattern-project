
package products;


public class ItalianDessert implements Dessert {
      public void make() {
        System.out.println("Making Italian dessert ");
    }
    
}
