
package products;


public class FastFoodMeal implements Meal {
      public void prepare() {
        System.out.println("Preparing fast food meal");
    }
    
}
