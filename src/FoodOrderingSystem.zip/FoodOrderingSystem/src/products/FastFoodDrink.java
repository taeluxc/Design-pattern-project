
package products;


public class FastFoodDrink implements Drink {
     public void serve() {
        System.out.println("Serving fast food drink");
    }
    
}
