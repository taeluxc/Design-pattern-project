
package products;

public interface Meal {
        void prepare();
}
