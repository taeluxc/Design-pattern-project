
package products;


public class FastFoodDessert implements Dessert {
      public void make() {
        System.out.println("Making fast food dessert");
    }
    
    
}
