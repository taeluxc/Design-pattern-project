
package products;

public class ItalianDrink implements Drink {
    public void serve() {
        System.out.println("Serving Italian drink ");
    }
}
