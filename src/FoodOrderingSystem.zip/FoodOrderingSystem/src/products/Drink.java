
package products;


public interface Drink {
        void serve();
}
