
package products;


public class ItalianMeal  implements Meal{
     public void prepare() {
        System.out.println("Preparing Italian meal");
    }
    
}
