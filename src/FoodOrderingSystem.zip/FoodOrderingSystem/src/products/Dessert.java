
package products;


public interface Dessert {
       void make();
}
